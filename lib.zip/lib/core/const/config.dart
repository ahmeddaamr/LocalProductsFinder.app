class config {
  static const URI = "https://f7e4-102-41-98-85.ngrok-free.app/";
  static const API_key = '2uQPCNLi4kjfUudfXFCC6ySbxRh_2hf4ZgfEA4eNJmVKPBLQD';
}
