
import 'package:flutter/material.dart';

class MyColors {
static  Color buttonColor = const Color.fromRGBO(45, 193, 82, 1);
static Color whiteColor = const Color.fromRGBO(255, 255, 255, 1);
static Color backgroundColor = const Color.fromRGBO(255, 255, 255, 1);
static Color fontColor  =Colors.black;
static Color searchFontColor = const Color.fromARGB(142, 142, 147, 1);
//static Color homeBackgroundColor = Color.fromARGB(226, 204, 255, 183)  ;
static Color greenColor = Colors.green ;
static Color arrowColor =  Colors.grey;
static Color blackColor = Colors.black ;
static Color homeBackgroundColor = const Color.fromRGBO(242,248,244,1);    

}


