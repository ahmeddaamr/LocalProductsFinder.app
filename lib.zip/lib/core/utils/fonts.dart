class MyFonts
{
static String montserratFont = "Montserrat";
}