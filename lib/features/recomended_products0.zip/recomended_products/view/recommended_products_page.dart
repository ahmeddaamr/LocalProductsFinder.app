import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/core/const/config.dart';
import 'package:flutter_application_1/core/models/product.dart';
import 'package:flutter_application_1/core/utils/colors.dart';
import 'package:flutter_application_1/core/utils/string.dart';
import 'package:flutter_application_1/features/home/widgets/bottom_nav_bar.dart';
import 'package:flutter_application_1/features/home/widgets/product_card.dart';
import 'package:flutter_application_1/features/recomended_products/widgets/headerWidget.dart';
import 'package:http/http.dart' as http;

class RecommendedProductsPage extends StatelessWidget {
  final int productId;

  const RecommendedProductsPage({super.key, required this.productId});

  /// Fetch recommended products from the backend API
  Future<List<Map<String, dynamic>>> recommend(int productId) async {
    var url = Uri.parse('${config.URI}/recommend/$productId');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(jsonResponse);
      } else {
        print("❌ Failed to get recommendations: ${response.statusCode}");
        return [];
      }
    } catch (e) {
      print("❌ Error getting recommendations: $e");
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColors.whiteColor,
      body: Column(
        children: [
          buildCustomHeader(
            context: context,
            title: 'Recommended Similar Products',
            onBack: () {
              if (Navigator.canPop(context)) {
                Navigator.pop(context);
              } else {
                Navigator.pushReplacementNamed(context, Routes.camera);
              }
            },
          ),

          /// 🔽 Expanded to wrap FutureBuilder's ListView
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: recommend(productId),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(
                    child: Text("No recommendations available."),
                  );
                }

                final recommendedProducts = snapshot.data!;

                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: recommendedProducts.length,
                  itemBuilder: (context, index) {
                    final data = recommendedProducts[index];

                    final product = Product(
                      productId: int.tryParse(data["Product ID"]?.toString() ?? '') ?? 0,
                      name: data["Product Description"] ?? 'Unknown Product',
                      category: data["Product Category"] ?? 'Unknown Category',
                      subcategory: data["Sub-Category"] ?? 'Unknown Subcategory',
                      isLocal: data["Local"] ?? "cannot identify",
                      rating: double.tryParse(data["average_rating"]?.toString() ?? '') ?? 0,
                      ratings_count: int.tryParse(data["rating_count"]?.toString() ?? '') ?? 0,
                    );

                    return ProductCard(product: product);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
